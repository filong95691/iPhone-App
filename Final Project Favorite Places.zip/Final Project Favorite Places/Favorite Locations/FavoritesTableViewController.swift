//
//  FavoritesTableViewController.swift
//  Favorite Locations
//  Table contains list of saved locations
//  Created by fil on 5/7/18.
//  Copyright © 2018 fil. All rights reserved.
//

import UIKit

class FavoritesTableViewController: UITableViewController {

    var selectedRow = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        favoritePlace.reloadFavorites()
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return favoritePlace.favoritesList.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "favoriteCell", for: indexPath)

        cell.textLabel?.text = favoritePlace.favoritesList[indexPath.row].name
        cell.detailTextLabel?.text = favoritePlace.favoritesList[indexPath.row].formatted_address

        return cell
    }
    
    //reload the data and displays it when the table view is review again
    override func viewDidAppear(_ animated: Bool) {
        self.tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        selectedRow = indexPath.row
        performSegue(withIdentifier: "favoritesSegue", sender: nil)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? LocationInfoViewController{
            destination.currentPlace = favoritePlace.favoritesList[selectedRow]
        }
    }


    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete
        {
            favoritePlace.removeFromFavPlace(trackIndex: indexPath.row)
            self.tableView.reloadData()
        }
    }
    
    


}
