//
//  OpenOtherApp.swift
//  FavoriteLocations
//
//  Created by fil on 5/19/18.
//  Copyright © 2018 fil. All rights reserved.
//

import Foundation

func openMapApp(latitude:String, longitude:String) {
    //let app =  UIApplication.sharedApplication()
    
    //For Google Maps
    let testURL = URL.init(string: "comgooglemaps-x-callback://")
    
    //For Google Maps
    if UIApplication.shared.canOpenURL(testURL!) {
        var direction:String = ""
        direction = String(format: "comgooglemaps-x-callback://?daddr=%@,%@&x-success=sourceapp://?resume=true&x-source=AirApp", latitude, longitude)
        
        let directionsURL = URL.init(string: direction)
        if #available(iOS 10, *) {
            UIApplication.shared.open(directionsURL!)
        } else {
            UIApplication.shared.openURL(directionsURL!)
        }
    }
        //For SAFARI Browser
    else {
        var direction:String = ""
        direction = String(format: "http://maps.google.com/maps?q=%@,%@", latitude, longitude)
        direction = direction.replacingOccurrences(of: " ", with: "+")
        
        let directionsURL = URL.init(string: direction)
        if #available(iOS 10, *) {
            UIApplication.shared.open(directionsURL!)
        } else {
            UIApplication.shared.openURL(directionsURL!)
        }
        
    }
}
