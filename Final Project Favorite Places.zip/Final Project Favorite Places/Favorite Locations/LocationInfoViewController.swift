//
//  LocationInfoViewController.swift
//  Favorite Locations
//  Screen to view, save, take notes on a Location
//  Created by fil on 5/1/18.
//  Copyright © 2018 fil. All rights reserved.
//

import UIKit
import AVFoundation //audio visual foundation to play song clips

class LocationInfoViewController: UIViewController, UITextViewDelegate  {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var userNotesTxt: UITextView!
    
    @IBOutlet weak var addressLbl: UILabel!
    var currentPlace: PlaceStruct?
    
    @IBAction func directionsBtn(_ sender: UIButton) {
        var latitude = 0.0
        var longitude = 0.0
        var okToOpenMaps = true
        
        if let lat = currentPlace?.lat {
            latitude = lat
        } else {
            okToOpenMaps = false
        }
        
        if let lng = currentPlace?.lng{
            longitude = lng
        }else{
            okToOpenMaps = false
        }

        if okToOpenMaps {
            
            openMapApp(latitude: String(latitude), longitude: String(longitude))
        }
    }
    
    @IBAction func addToFavBtn(_ sender: UIButton) {
        currentPlace?.notes = userNotesTxt.text
        favoritePlace.addToFavoritesTrack(newPlace: currentPlace)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userNotesTxt.delegate = self

        // Do any additional setup after loading the view.
        nameLbl.text = currentPlace?.name
        addressLbl.text = currentPlace?.formatted_address
        if let notes = currentPlace?.notes {
            userNotesTxt.text = notes
        }
        
    }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }

    func openMapApp(latitude:String, longitude:String) {
        //let app =  UIApplication.sharedApplication()
        
        //For Google Maps
        let testURL = URL.init(string: "comgooglemaps-x-callback://")
        
        //For Google Maps
        if UIApplication.shared.canOpenURL(testURL!) {
            var direction:String = ""
            direction = String(format: "comgooglemaps-x-callback://?daddr=%@,%@&x-success=sourceapp://?resume=true&x-source=AirApp", latitude, longitude)
            
            let directionsURL = URL.init(string: direction)
            if #available(iOS 10, *) {
                UIApplication.shared.open(directionsURL!)
            } else {
                UIApplication.shared.openURL(directionsURL!)
            }
        }
            //For SAFARI Browser
        else {
            var direction:String = ""
            direction = String(format: "http://maps.google.com/maps?q=%@,%@", latitude, longitude)
            direction = direction.replacingOccurrences(of: " ", with: "+")
            
            let directionsURL = URL.init(string: direction)
            if #available(iOS 10, *) {
                UIApplication.shared.open(directionsURL!)
            } else {
                UIApplication.shared.openURL(directionsURL!)
            }
            
        }
    }
}
