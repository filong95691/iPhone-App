//
//  Favorites.swift
//  MusicPlayer
//  Class used by FavoritesTableViewController.swift
//  Created by fil on 5/7/18.
//  Copyright © 2018 fil. All rights reserved.
//

import Foundation

//this class stores what is displayed in the favorites controller and addes, deltes, checks for duplicates
class Favorites{

    var favoritesList = [PlaceStruct]()
    
    func addToFavoritesTrack(newPlace: PlaceStruct?) {

        if let newPlace = newPlace{
            removeDuplicate(aPlace: newPlace)
            favoritesList.append(newPlace)
            saveFavorites()
        }
    }
    
    func removeDuplicate(aPlace: PlaceStruct){
        var index = 0
        for favList in favoritesList {
            if favList.place_id == aPlace.place_id{
                favoritesList.remove(at: index)
            }
            index += 1
        }

    }
    
    
    func removeFromFavPlace(trackIndex: Int){
        favoritesList.remove(at: trackIndex)
        saveFavorites()
    }
    
    func saveFavorites(){
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let archiveURL = documentsDirectory[0].appendingPathComponent("locationFav").appendingPathExtension("plist")
        let propertyListEncoder = PropertyListEncoder()
        let encodedNote = try? propertyListEncoder.encode(favoritesList)
        try? encodedNote?.write(to: archiveURL, options: .noFileProtection)
        
    }
    
    func reloadFavorites(){
        
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let archiveURL = documentsDirectory[0].appendingPathComponent("locationFav").appendingPathExtension("plist")
        let propertyListDecoder = PropertyListDecoder()
        
        if let retrievedData = try? Data(contentsOf: archiveURL),
            let favTemp = try? propertyListDecoder.decode([PlaceStruct].self, from: retrievedData) {
            favoritesList = favTemp
        }
    }
        
}

internal var favoritePlace = Favorites()
