//
//  Query.swift
//  Favorite Locations
//  Stores functions and structs to build proper URL and get results
//  Created by Fil Ong on 4/20/18.
//  Copyright © 2018 Fil Ong. All rights reserved.
//

import Foundation

// make an extension to create a URL with some queries as a parameter
extension URL {
    func withQueries(_ queries: [String: String]) -> URL? {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map { URLQueryItem(name: $0.0, value: $0.1) }
        return components?.url
    }
}

let baseURL = URL(string: "https://maps.googleapis.com/maps/api/place/textsearch/json")!


//several struct used by JSON decoder to get data from Google API
struct Location: Codable {
    let lat: Double
    let lng: Double
    
    enum CodingKeys: String, CodingKey {
        case lat
        case lng
    }
}

struct Geometry: Codable{
    let location: Location
    
    enum CodingKeys: String, CodingKey {
        case location
    }
}

struct PlaceInfo: Codable {
    let formatted_address: String
    let name: String
    let place_id: String
    let geometry: Geometry
    
    enum CodingKeys: String, CodingKey {
        case formatted_address
        case name
        case place_id
        case geometry
    }
}

// main struct to hold to results from API server query
struct Results: Codable {
    let results: [PlaceInfo]
    
    enum CodingKeys: String, CodingKey {
        case results
    }
}


// createURL creates a URL to query to API* server for info
func createURL(searchText: String) -> URL? {
    //replace a space with +, can't use space in google maps query
    let searchFormatted = String(searchText.map {
        $0 == " " ? "+" : $0
    })
    
    let urlQuery: [String: String] = [
        "query": searchFormatted,
        "key": "AIzaSyCOHr72s6Y7BFGSbqSwUb_eeYseLrSDy8M"
    ]
    
    return baseURL.withQueries(urlQuery)
}

//struct used to store info going between screens and saving records, not used for URL or to get JSON
struct PlaceStruct: Codable{
    var formatted_address: String?
    var name: String
    var place_id: String
    var notes: String?
    var priority: Int?
    var lng: Double?
    var lat: Double?
}
