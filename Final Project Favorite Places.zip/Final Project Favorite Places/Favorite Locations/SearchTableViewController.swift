//
//  SearchTableViewController.swift
//  Favorite Locations
//  Contains search and list of results from the search
//  Created by fil on 5/1/18.
//  Copyright © 2018 fil. All rights reserved.
//

import UIKit

class SearchTableViewController: UITableViewController , UISearchBarDelegate{
    
    //if no ?, then var must be initialized
    var searchTerm: String?
    var placesArray: [PlaceInfo] = []
    var selectedRow = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return placesArray.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "trackCell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = placesArray[indexPath.row].name
        cell.detailTextLabel?.text = placesArray[indexPath.row].formatted_address
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedRow = indexPath.row
        performSegue(withIdentifier: "searchToInfoSegue", sender: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //need to downcast
        if let destination = segue.destination as? LocationInfoViewController{
            destination.currentPlace = PlaceStruct(formatted_address: placesArray[selectedRow].formatted_address, name: placesArray[selectedRow].name, place_id: placesArray[selectedRow].place_id, notes: nil, priority: nil,
                lng: placesArray[selectedRow].geometry.location.lng, lat: placesArray[selectedRow].geometry.location.lat )
        }
    }

    //MARK: - search bar delegate
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if let searchTerm = searchBar.text{
            search(term: searchTerm)
        }
        searchBar.resignFirstResponder()
    }
    
    func search(term: String){
        if let url = createURL(searchText: term){
            let task = URLSession.shared.dataTask(with: url){(data, response, error) in
                if let error = error{
                    print(error)
                    return
                }
                
                if let data = data {
                    let jsonDecoder = JSONDecoder()

                    //if you have code that can throw an error, you need a try
                    if let result = try? jsonDecoder.decode(Results.self, from: data){
                        self.placesArray = result.results
                        DispatchQueue.main.sync {
                            self.tableView.reloadData()
                        }
                    }
                }
            }
            task.resume()
        }
    }
    

}
